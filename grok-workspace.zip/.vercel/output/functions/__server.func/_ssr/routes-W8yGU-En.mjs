import { i as __toESM } from "../_runtime.mjs";
import { K as require_react, b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as Plus, c as Download, i as RotateCcw, l as Copy, o as NotebookPen, r as Trash2, s as Minus, t as Upload } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-W8yGU-En.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Field({ label, hint, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block min-w-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mb-1.5 block text-sm font-medium text-ink",
				children: label
			}),
			children,
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "mt-1.5 block text-xs leading-relaxed text-muted",
				children: hint
			}) : null
		]
	});
}
function NumField({ value, onChange, label, integer, emptyZero, placeholder, center, maxDecimals = 2 }) {
	const [draft, setDraft] = (0, import_react.useState)(null);
	const shown = draft !== null ? draft : value === 0 && emptyZero ? "" : integer ? String(Math.round(value)) : strip(value);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		"aria-label": label,
		inputMode: integer ? "numeric" : "decimal",
		autoComplete: "off",
		placeholder,
		className: `field tabular-nums ${center ? "text-center" : ""}`,
		value: shown,
		onFocus: () => {
			setDraft(value === 0 && emptyZero ? "" : integer ? String(Math.round(value)) : strip(value));
		},
		onBlur: () => setDraft(null),
		onChange: (e) => {
			const raw = e.target.value.replace(",", ".").replace(/\s/g, "");
			if (!(integer ? /^\d{0,6}$/ : new RegExp(`^\\d{0,7}(\\.\\d{0,${maxDecimals}})?$`)).test(raw)) return;
			setDraft(raw);
			if (raw === "" || raw === ".") onChange(0);
			else onChange(Number(raw));
		}
	});
}
function strip(n) {
	if (!Number.isFinite(n)) return "";
	return String(Math.round(n * 1e3) / 1e3);
}
function Stepper({ value, onChange, label, min = 1, max = 999 }) {
	const current = Math.max(0, Math.round(value || 0));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": `${label} azalt`,
				className: "grid size-11 shrink-0 place-items-center rounded-xl border border-line bg-surface text-ink",
				onClick: () => onChange(Math.max(min, (current || min) - 1)),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Minus, {
					className: "size-4",
					"aria-hidden": true
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
				integer: true,
				center: true,
				label,
				value: current,
				onChange: (n) => onChange(Math.min(max, Math.max(min, Math.round(n) || min)))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				"aria-label": `${label} artır`,
				className: "grid size-11 shrink-0 place-items-center rounded-xl border border-line bg-surface text-ink",
				onClick: () => onChange(Math.min(max, (current || min) + 1)),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
					className: "size-4",
					"aria-hidden": true
				})
			})
		]
	});
}
function SelectField({ label, value, onChange, options }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
		"aria-label": label,
		className: "field",
		value,
		onChange: (e) => onChange(e.target.value),
		children: options.map((option) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
			value: option.value,
			children: option.label
		}, option.value))
	});
}
function IncludeButton({ on, onChange, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		"aria-label": `${label}: ${on ? "fiyata dahil" : "hariç"}`,
		onClick: () => onChange(!on),
		className: `h-11 shrink-0 rounded-full px-4 text-sm font-medium ${on ? "bg-ink text-surface" : "bg-inset text-muted"}`,
		children: on ? "Dahil" : "Hariç"
	});
}
function Button({ children, onClick, tone = "ghost", disabled }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		disabled,
		onClick,
		className: `inline-flex h-11 items-center justify-center gap-2 rounded-xl px-4 text-sm font-medium disabled:opacity-40 ${tone === "solid" ? "bg-copper-deep text-copper-ink" : tone === "quiet" ? "bg-inset text-ink" : "border border-line bg-surface text-ink"}`,
		children
	});
}
/** Turkish-style numbers without relying on ICU (SSR and browser stay identical). */
function formatNum(n, digits = 2) {
	if (!Number.isFinite(n)) return digits > 0 ? `0,${"0".repeat(digits)}` : "0";
	const sign = n < 0 ? "-" : "";
	const [whole, frac] = Math.abs(n).toFixed(digits).split(".");
	const grouped = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
	return digits > 0 ? `${sign}${grouped},${frac}` : `${sign}${grouped}`;
}
function formatTL(n, digits = 2) {
	return `${formatNum(n, digits)} TL`;
}
function formatTLInt(n) {
	return `${formatNum(Math.round(n), 0)} TL`;
}
/** Whole lira, rounding up, stable on floating-point noise. */
function ceilTL(n) {
	if (!Number.isFinite(n) || n <= 0) return 0;
	return Math.ceil(n - 1e-6);
}
function formatMult(n) {
	if (!Number.isFinite(n)) return "x0";
	const r = Math.round(n * 100) / 100;
	return `x${formatNum(r, Number.isInteger(r) ? 0 : Math.abs(r * 10 - Math.round(r * 10)) < 1e-6 ? 1 : 2)}`;
}
function formatDuration(hours) {
	if (!Number.isFinite(hours) || hours <= 0) return "0 dk";
	const totalMin = Math.round(hours * 60);
	const h = Math.floor(totalMin / 60);
	const m = totalMin % 60;
	if (h <= 0) return `${m} dk`;
	if (m === 0) return `${h} sa`;
	return `${h} sa ${m} dk`;
}
var FILAMENTS = [
	{
		id: "pla",
		label: "PLA",
		price: 753
	},
	{
		id: "pla_plus",
		label: "PLA+",
		price: 850
	},
	{
		id: "petg",
		label: "PETG",
		price: 850
	},
	{
		id: "abs",
		label: "ABS",
		price: 800
	},
	{
		id: "asa",
		label: "ASA",
		price: 950
	},
	{
		id: "tpu",
		label: "TPU",
		price: 1100
	},
	{
		id: "custom",
		label: "Özel",
		price: 0
	}
];
var PRINTERS = [
	{
		id: "kayitli",
		label: "Dosyandaki tezgah",
		watt: 120,
		cost: 25e3,
		life: 3e3
	},
	{
		id: "a1",
		label: "Bambu Lab A1",
		watt: 120,
		cost: 25e3,
		life: 5e3
	},
	{
		id: "a1mini",
		label: "Bambu Lab A1 Mini",
		watt: 90,
		cost: 16e3,
		life: 5e3
	},
	{
		id: "p1s",
		label: "Bambu Lab P1S",
		watt: 180,
		cost: 45e3,
		life: 6e3
	},
	{
		id: "x1c",
		label: "Bambu Lab X1C",
		watt: 200,
		cost: 7e4,
		life: 6e3
	},
	{
		id: "ender",
		label: "Creality Ender serisi",
		watt: 150,
		cost: 9e3,
		life: 2500
	},
	{
		id: "ozel",
		label: "El ile",
		watt: 120,
		cost: 25e3,
		life: 3e3
	}
];
var INCLUDE_KEYS = [
	"material",
	"waste",
	"support",
	"electricity",
	"printer",
	"nozzle",
	"pei",
	"fail",
	"labor",
	"design",
	"packaging",
	"shipping",
	"commission",
	"tax"
];
function uid() {
	return Math.random().toString(36).slice(2, 10);
}
function defaultInclude() {
	return {
		material: true,
		waste: true,
		support: true,
		electricity: true,
		printer: true,
		nozzle: true,
		pei: true,
		fail: true,
		labor: false,
		design: false,
		packaging: false,
		shipping: false,
		commission: false,
		tax: false
	};
}
function defaultWorkshop() {
	return {
		printerId: "kayitli",
		watt: 120,
		elecRate: 4.5,
		printerCost: 25e3,
		printerLife: 3e3,
		nozzleCost: 1500,
		nozzleLife: 500,
		peiCost: 3500,
		peiLife: 300,
		failRate: 10,
		wasteRate: 15,
		laborRate: 200,
		commissionRate: 0,
		taxRate: 0,
		multiMin: 2.5,
		multiRec: 3.5,
		multiMax: 5,
		include: defaultInclude()
	};
}
function defaultJob() {
	return {
		name: "",
		filamentId: "pla",
		filamentPrice: 753,
		grams: 0,
		hours: 0,
		minutes: 0,
		qty: 1,
		perPlate: 1,
		supportGrams: 0,
		supportPrice: 850,
		prepMin: 15,
		postMin: 10,
		design: 0,
		packaging: 15,
		packagingPer: "order",
		shipping: 0,
		extras: [],
		customPrice: 0
	};
}
function defaults() {
	return {
		v: 1,
		workshop: defaultWorkshop(),
		job: defaultJob(),
		profiles: [],
		notes: []
	};
}
function applyExample(job) {
	return {
		...job,
		name: job.name.trim() ? job.name : "Küçük parça",
		grams: 3,
		hours: 0,
		minutes: 30,
		qty: 1,
		perPlate: 4
	};
}
function num(v, fallback) {
	const n = typeof v === "number" ? v : typeof v === "string" ? Number(v) : NaN;
	return Number.isFinite(n) ? n : fallback;
}
function normalizeExtras(v) {
	if (!Array.isArray(v)) return [];
	return v.slice(0, 12).map((item, i) => {
		const it = item ?? {};
		return {
			id: typeof it.id === "string" && it.id ? it.id : `e${i}`,
			name: typeof it.name === "string" && it.name.trim() ? it.name.slice(0, 40) : "Ek kalem",
			amount: Math.max(0, num(it.amount, 0)),
			per: it.per === "piece" ? "piece" : "order"
		};
	});
}
function normalizeWorkshop(raw) {
	const base = defaultWorkshop();
	const r = raw ?? {};
	const include = { ...base.include };
	if (r.include && typeof r.include === "object") for (const key of INCLUDE_KEYS) {
		const value = r.include[key];
		if (typeof value === "boolean") include[key] = value;
	}
	return {
		printerId: typeof r.printerId === "string" ? r.printerId : base.printerId,
		watt: num(r.watt, base.watt),
		elecRate: num(r.elecRate, base.elecRate),
		printerCost: num(r.printerCost, base.printerCost),
		printerLife: num(r.printerLife, base.printerLife),
		nozzleCost: num(r.nozzleCost, base.nozzleCost),
		nozzleLife: num(r.nozzleLife, base.nozzleLife),
		peiCost: num(r.peiCost, base.peiCost),
		peiLife: num(r.peiLife, base.peiLife),
		failRate: num(r.failRate, base.failRate),
		wasteRate: num(r.wasteRate, base.wasteRate),
		laborRate: num(r.laborRate, base.laborRate),
		commissionRate: num(r.commissionRate, base.commissionRate),
		taxRate: num(r.taxRate, base.taxRate),
		multiMin: num(r.multiMin, base.multiMin),
		multiRec: num(r.multiRec, base.multiRec),
		multiMax: num(r.multiMax, base.multiMax),
		include
	};
}
function normalizeJob(raw) {
	const base = defaultJob();
	const r = raw ?? {};
	return {
		name: typeof r.name === "string" ? r.name.slice(0, 80) : base.name,
		filamentId: typeof r.filamentId === "string" ? r.filamentId : base.filamentId,
		filamentPrice: num(r.filamentPrice, base.filamentPrice),
		grams: num(r.grams, base.grams),
		hours: num(r.hours, base.hours),
		minutes: num(r.minutes, base.minutes),
		qty: num(r.qty, base.qty),
		perPlate: num(r.perPlate, base.perPlate),
		supportGrams: num(r.supportGrams, base.supportGrams),
		supportPrice: num(r.supportPrice, base.supportPrice),
		prepMin: num(r.prepMin, base.prepMin),
		postMin: num(r.postMin, base.postMin),
		design: num(r.design, base.design),
		packaging: num(r.packaging, base.packaging),
		packagingPer: r.packagingPer === "piece" ? "piece" : "order",
		shipping: num(r.shipping, base.shipping),
		extras: normalizeExtras(r.extras),
		customPrice: num(r.customPrice, base.customPrice)
	};
}
function normalizePersisted(raw) {
	const base = defaults();
	if (!raw || typeof raw !== "object") return base;
	const r = raw;
	const profiles = [];
	if (Array.isArray(r.profiles)) for (const item of r.profiles.slice(0, 12)) {
		if (!item || typeof item !== "object") continue;
		const it = item;
		profiles.push({
			id: typeof it.id === "string" ? it.id : uid(),
			name: typeof it.name === "string" && it.name.trim() ? it.name.slice(0, 40) : "Profil",
			workshop: normalizeWorkshop(it.workshop)
		});
	}
	const notes = [];
	if (Array.isArray(r.notes)) for (const item of r.notes.slice(0, 8)) {
		if (!item || typeof item !== "object") continue;
		const it = item;
		notes.push({
			id: typeof it.id === "string" ? it.id : uid(),
			at: typeof it.at === "string" ? it.at.slice(0, 40) : "",
			name: typeof it.name === "string" ? it.name.slice(0, 80) : "İş",
			price: typeof it.price === "string" ? it.price.slice(0, 40) : "",
			job: normalizeJob(it.job)
		});
	}
	return {
		v: 1,
		workshop: normalizeWorkshop(r.workshop),
		job: normalizeJob(r.job),
		profiles,
		notes
	};
}
var STORAGE_KEY = "baski-maliyet-v1";
function loadPersisted() {
	try {
		const raw = localStorage.getItem(STORAGE_KEY);
		if (!raw) return defaults();
		return normalizePersisted(JSON.parse(raw));
	} catch {
		return defaults();
	}
}
function savePersisted(data) {
	try {
		localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
	} catch {}
}
function burnRate(w) {
	const printerPerHour = w.printerLife > 0 ? Math.max(0, w.printerCost) / w.printerLife : 0;
	const nozzlePerHour = w.nozzleLife > 0 ? Math.max(0, w.nozzleCost) / w.nozzleLife : 0;
	const elecPerHour = Math.max(0, w.watt) / 1e3 * Math.max(0, w.elecRate);
	const peiPerPlate = w.peiLife > 0 ? Math.max(0, w.peiCost) / w.peiLife : 0;
	return {
		printerPerHour,
		nozzlePerHour,
		elecPerHour,
		realPerHour: printerPerHour + nozzlePerHour + elecPerHour,
		pricedPerHour: (w.include.printer ? printerPerHour : 0) + (w.include.nozzle ? nozzlePerHour : 0) + (w.include.electricity ? elecPerHour : 0),
		peiPerPlate,
		laborPerHour: Math.max(0, w.laborRate)
	};
}
function laborAmount(job, rate) {
	const qty = Math.max(1, Math.round(job.qty || 1));
	return Math.max(0, job.prepMin) / 60 * Math.max(0, rate) + Math.max(0, job.postMin) / 60 * Math.max(0, rate) * qty;
}
function keptFraction(w) {
	const commission = w.include.commission ? Math.max(0, w.commissionRate) / 100 : 0;
	const taxPct = w.include.tax ? Math.max(0, w.taxRate) : 0;
	const tax = taxPct > 0 ? taxPct / (100 + taxPct) : 0;
	return 1 - commission - tax;
}
function emptyAnalysis(burn, fraction) {
	return {
		ready: false,
		missing: null,
		problem: null,
		burn,
		pieceHours: 0,
		totalHours: 0,
		plateCycles: 0,
		totalGrams: 0,
		kwh: 0,
		lines: [],
		production: 0,
		direct: 0,
		unitDirect: 0,
		filamentOnly: 0,
		linearDirect: 0,
		linearPriceRec: null,
		failExpected: 0,
		failLinear: 0,
		feeFraction: fraction,
		prices: null,
		commissionOnRec: 0,
		taxOnRec: 0,
		receivedOnRec: 0,
		profitOnRec: 0,
		marginOnRec: 0,
		netMultiplier: 0,
		unitRec: 0,
		dominantKey: null,
		excludedLabels: [],
		insights: [],
		ladder: []
	};
}
function ladderQuantities(perPlate, current) {
	const plate = Math.max(1, Math.round(perPlate || 1));
	const raw = [
		1,
		2,
		5,
		10,
		plate,
		plate * 2,
		Math.max(1, Math.round(current || 1))
	];
	return [...new Set(raw.map((n) => Math.max(1, Math.round(n))).filter((n) => n <= 80))].sort((a, b) => a - b).slice(0, 6);
}
function compute(job, workshop) {
	const burn = burnRate(workshop);
	const fraction = keptFraction(workshop);
	const base = emptyAnalysis(burn, fraction);
	const qty = Math.max(1, Math.round(Number.isFinite(job.qty) ? job.qty : 1));
	const perPlate = Math.max(1, Math.round(Number.isFinite(job.perPlate) ? job.perPlate : 1));
	const pieceHours = Math.max(0, job.hours) + Math.max(0, job.minutes) / 60;
	const totalHours = pieceHours * qty;
	const grams = Math.max(0, job.grams);
	const totalGrams = grams * qty;
	const plateCycles = Math.ceil(qty / perPlate);
	const ready = grams > 0 && pieceHours > 0;
	let missing = null;
	if (!ready) {
		if (grams <= 0 && pieceHours <= 0) missing = "Dilimleyiciden gramı ve baskı süresini yaz.";
		else if (grams <= 0) missing = "Filament gramı eksik.";
		else missing = "Baskı süresi eksik. En az bir dakika yaz.";
	}
	let problem = null;
	if (workshop.failRate >= 100) problem = "Başarısızlık %100 ise iyi parça çıkmaz. Oranı 80'in altında tut.";
	else if (fraction <= 0) problem = "Komisyon ve vergi birlikte tahsilatı yutuyor. Oranları düşür.";
	else if (workshop.multiRec <= 0 || workshop.multiMin <= 0 || workshop.multiMax <= 0) problem = "Satış çarpanları sıfırdan büyük olmalı.";
	const materialCost = totalGrams / 1e3 * Math.max(0, job.filamentPrice);
	const supportGrams = Math.max(0, job.supportGrams) * qty;
	const supportCost = supportGrams / 1e3 * Math.max(0, job.supportPrice);
	const wasteCost = (materialCost + supportCost) * (Math.max(0, workshop.wasteRate) / 100);
	const kwh = totalHours * (Math.max(0, workshop.watt) / 1e3);
	const elecCost = kwh * Math.max(0, workshop.elecRate);
	const printerCost = burn.printerPerHour * totalHours;
	const nozzleCost = burn.nozzlePerHour * totalHours;
	const peiCost = burn.peiPerPlate * plateCycles;
	const labor = laborAmount(job, workshop.laborRate);
	const design = Math.max(0, job.design);
	const packaging = Math.max(0, job.packaging) * (job.packagingPer === "piece" ? qty : 1);
	const shipping = Math.max(0, job.shipping);
	const filamentName = FILAMENTS.find((f) => f.id === job.filamentId)?.label ?? "Filament";
	const prod = [{
		key: "material",
		label: "Hammadde",
		detail: `${formatNum(totalGrams, 2)} g ${filamentName} · ${formatTL(job.filamentPrice)}/kg`,
		amount: materialCost,
		included: workshop.include.material,
		group: "prod"
	}, {
		key: "waste",
		label: "Fire payı",
		detail: `Hammadde ve desteğin %${formatNum(workshop.wasteRate, 0)} kadarı. Dilimleyici gramına ek.`,
		amount: wasteCost,
		included: workshop.include.waste,
		group: "prod"
	}];
	if (supportGrams > 0) prod.push({
		key: "support",
		label: "Destek filament",
		detail: `${formatNum(supportGrams, 2)} g · ${formatTL(job.supportPrice)}/kg. Aynı malzemenin desteğini ana grama yazma.`,
		amount: supportCost,
		included: workshop.include.support,
		group: "prod"
	});
	prod.push({
		key: "electricity",
		label: "Elektrik",
		detail: `${formatNum(kwh, 3)} kWh · ${formatNum(workshop.watt, 0)} W ortalama · ${formatTL(workshop.elecRate)}/kWh`,
		amount: elecCost,
		included: workshop.include.electricity,
		group: "prod"
	}, {
		key: "printer",
		label: "Makine amortismanı",
		detail: `${formatTL(burn.printerPerHour)}/sa × ${formatDuration(totalHours)}`,
		amount: printerCost,
		included: workshop.include.printer,
		group: "prod"
	}, {
		key: "nozzle",
		label: "Nozzle",
		detail: `${formatTL(burn.nozzlePerHour)}/sa × ${formatDuration(totalHours)}`,
		amount: nozzleCost,
		included: workshop.include.nozzle,
		group: "prod"
	}, {
		key: "pei",
		label: "PEI plaka",
		detail: `${plateCycles} tabla × ${formatTL(burn.peiPerPlate)}. Süreye değil, döngüye yazılıyor.`,
		amount: peiCost,
		included: workshop.include.pei,
		group: "prod"
	});
	const pieceExtras = job.extras.filter((e) => e.per === "piece");
	const orderExtras = job.extras.filter((e) => e.per !== "piece");
	for (const extra of pieceExtras) prod.push({
		key: `extra:${extra.id}`,
		label: extra.name || "Ek kalem",
		detail: `${formatTL(extra.amount)} × ${qty} adet. Başarısız denemede de gider.`,
		amount: Math.max(0, extra.amount) * qty,
		included: true,
		group: "prod"
	});
	const p = Math.max(0, workshop.failRate) / 100;
	const failBase = prod.filter((line) => line.included).reduce((sum, line) => sum + line.amount, 0);
	const failLinear = p > 0 && p < 1 ? failBase * p : 0;
	const failExpected = p > 0 && p < 1 ? failBase * (p / (1 - p)) : 0;
	prod.push({
		key: "fail",
		label: "Başarısız baskı",
		detail: p > 0 && p < 1 ? `%${formatNum(workshop.failRate, 0)} → iyi tabla başına ${formatNum(1 / (1 - p), 2)} deneme. Düz yüzde değil.` : "Kapalı ya da sıfır.",
		amount: failExpected,
		included: workshop.include.fail && p > 0 && p < 1,
		group: "prod"
	});
	const work = [
		{
			key: "labor",
			label: "İşçilik",
			detail: `Hazırlık ${formatNum(job.prepMin, 0)} dk bir kez + son işlem ${formatNum(job.postMin, 0)} dk × ${qty}. ${formatTL(workshop.laborRate, 0)}/sa.`,
			amount: labor,
			included: workshop.include.labor,
			group: "work"
		},
		{
			key: "design",
			label: "Tasarım",
			detail: "Siparişe bir kez. Adet artınca birim fiyat düşer.",
			amount: design,
			included: workshop.include.design,
			group: "work"
		},
		{
			key: "packaging",
			label: "Paketleme",
			detail: job.packagingPer === "piece" ? "Adet başı." : "Siparişe bir kez.",
			amount: packaging,
			included: workshop.include.packaging,
			group: "work"
		},
		{
			key: "shipping",
			label: "Kargo",
			detail: "Siparişe bir kez.",
			amount: shipping,
			included: workshop.include.shipping,
			group: "work"
		}
	];
	for (const extra of orderExtras) work.push({
		key: `extra:${extra.id}`,
		label: extra.name || "Ek kalem",
		detail: "Siparişe bir kez.",
		amount: Math.max(0, extra.amount),
		included: true,
		group: "work"
	});
	const lines = [...prod, ...work].filter((line) => line.amount >= .005);
	const production = lines.filter((line) => line.group === "prod" && line.included).reduce((sum, line) => sum + line.amount, 0);
	const direct = lines.filter((line) => line.included).reduce((sum, line) => sum + line.amount, 0);
	const linearDirect = workshop.include.fail ? direct - failExpected + failLinear : direct;
	if (ready && !problem && direct <= 0) problem = "Fiyata dahil hiçbir kalem yok. En azından hammaddeyi aç.";
	const canPrice = ready && !problem && direct > 0 && fraction > 0;
	const prices = canPrice ? {
		min: ceilTL(direct * workshop.multiMin / fraction),
		rec: ceilTL(direct * workshop.multiRec / fraction),
		max: ceilTL(direct * workshop.multiMax / fraction)
	} : null;
	const linearPriceRec = canPrice && Math.abs(fraction - 1) < 1e-9 ? ceilTL(linearDirect * workshop.multiRec) : null;
	const rec = prices?.rec ?? 0;
	const commissionOnRec = workshop.include.commission ? rec * (Math.max(0, workshop.commissionRate) / 100) : 0;
	const taxPct = workshop.include.tax ? Math.max(0, workshop.taxRate) : 0;
	const taxOnRec = taxPct > 0 ? rec * (taxPct / (100 + taxPct)) : 0;
	const receivedOnRec = rec - commissionOnRec - taxOnRec;
	const profitOnRec = receivedOnRec - direct;
	const marginOnRec = rec > 0 ? profitOnRec / rec * 100 : 0;
	const netMultiplier = direct > 0 ? receivedOnRec / direct : 0;
	const dominant = lines.filter((line) => line.included && line.amount > 0).reduce((best, line) => !best || line.amount > best.amount ? line : best, null);
	const excludedLabels = lines.filter((line) => !line.included && line.amount >= .5).map((line) => line.label);
	const insights = [];
	const laborLine = [...prod, ...work].find((line) => line.key === "labor");
	if (laborLine && !laborLine.included && laborLine.amount >= 1) insights.push({
		id: "labor",
		tone: "warn",
		text: `İşçilik kapalı. Bu işte hazırlık ve son işlem ${formatTL(laborLine.amount)} — fiyat emeğini taşımıyor.`
	});
	const peiLine = prod.find((line) => line.key === "pei");
	if (peiLine && peiLine.included && perPlate > qty && direct > 0 && peiLine.amount > direct * .25) insights.push({
		id: "plate",
		tone: "info",
		text: `Tabla ${perPlate} parça alır, sipariş ${qty} adet. Plaka payının tamamı bu parçaya yazılıyor. Tabla dolunca bu kalem bölünür.`
	});
	if (materialCost > 0 && direct > materialCost * 1.8) insights.push({
		id: "illusion",
		tone: "info",
		text: `Yalnızca filament ${formatTL(materialCost)}. Doğrudan maliyet bunun ${formatNum(direct / materialCost, 1)} katı.`
	});
	if (dominant && direct > 0 && dominant.amount / direct >= .4 && !(dominant.key === "pei" && insights.some((i) => i.id === "plate"))) insights.push({
		id: "dominant",
		tone: "info",
		text: `En büyük kalem ${dominant.label}. Maliyetin %${formatNum(dominant.amount / direct * 100, 0)}'i.`
	});
	if (workshop.include.fail && workshop.failRate >= 20 && workshop.failRate < 100) insights.push({
		id: "fail",
		tone: "warn",
		text: `Başarısızlık %${formatNum(workshop.failRate, 0)}. İyi tabla için ortalama ${formatNum(1 / (1 - workshop.failRate / 100), 2)} deneme gerekir.`
	});
	return {
		...base,
		ready,
		missing,
		problem,
		pieceHours,
		totalHours,
		plateCycles: ready ? plateCycles : 0,
		totalGrams,
		kwh,
		lines: ready ? lines : [],
		production: ready ? production : 0,
		direct: ready ? direct : 0,
		unitDirect: ready && qty > 0 ? direct / qty : 0,
		filamentOnly: ready ? materialCost : 0,
		linearDirect: ready ? linearDirect : 0,
		linearPriceRec,
		failExpected,
		failLinear,
		prices,
		commissionOnRec,
		taxOnRec,
		receivedOnRec: prices ? receivedOnRec : 0,
		profitOnRec: prices ? profitOnRec : 0,
		marginOnRec: prices ? marginOnRec : 0,
		netMultiplier: prices ? netMultiplier : 0,
		unitRec: prices ? rec / qty : 0,
		dominantKey: ready ? dominant?.key ?? null : null,
		excludedLabels: ready ? excludedLabels : [],
		insights: ready ? insights.slice(0, 3) : []
	};
}
function quote(job, workshop) {
	const base = compute(job, workshop);
	if (!base.prices) return base;
	const ladder = ladderQuantities(job.perPlate, job.qty).map((qty) => {
		const next = compute({
			...job,
			qty
		}, workshop);
		return {
			qty,
			cycles: next.plateCycles,
			unit: next.unitRec,
			total: next.prices?.rec ?? 0
		};
	});
	return {
		...base,
		ladder
	};
}
function judgePrice(price, analysis) {
	if (!(price > 0) || !(analysis.direct > 0) || !(analysis.feeFraction > 0)) return null;
	const received = price * analysis.feeFraction;
	const profit = received - analysis.direct;
	const multiplier = received / analysis.direct;
	const margin = profit / price * 100;
	const perGram = analysis.totalGrams > 0 ? profit / analysis.totalGrams : 0;
	let tone = "good";
	let text;
	if (profit < 0) {
		tone = "bad";
		text = `Kesintilerden sonra ${formatTL(Math.abs(profit))} zarar. Bu fiyat tezgahı döndürmez.`;
	} else if (multiplier < 2) {
		tone = "warn";
		text = "Eline geçen, maliyetin iki katının altında. Aksilik ve emek için dar.";
	} else if (multiplier < 3) {
		tone = "warn";
		text = "İdare eder. Seri, risksiz işte kalabilir; tek parça özel işte sıkışır.";
	} else if (multiplier < 5) text = "Maliyet kapanıyor, kâr da duruyor. Çoğu müşteri işi için sağlıklı bant.";
	else text = "Primli fiyat. Aciliyet, zahmet ya da az bulunan malzeme varsa yerinde.";
	return {
		tone,
		text,
		profit,
		margin,
		multiplier,
		received,
		perGram
	};
}
function buildQuote(job, workshop, analysis) {
	if (!analysis.prices) return "";
	const filament = FILAMENTS.find((f) => f.id === job.filamentId)?.label ?? "Filament";
	const qty = Math.max(1, Math.round(job.qty || 1));
	return [
		job.name.trim() ? `3D baskı teklifi — ${job.name.trim()}` : "3D baskı teklifi",
		`${filament}, ${formatNum(analysis.totalGrams, 1)} g`,
		`Süre ${formatDuration(analysis.totalHours)} · ${qty} adet · ${analysis.plateCycles} tabla`,
		`Önerilen fiyat: ${formatTLInt(analysis.prices.rec)}`,
		qty > 1 ? `Adet başı: ${formatTLInt(analysis.unitRec)}` : "",
		`Doğrudan maliyet: ${formatTL(analysis.direct)}`,
		workshop.include.labor ? "İşçilik dahil." : "İşçilik dahil değil.",
		workshop.include.shipping && job.shipping > 0 ? "Kargo dahil." : "Kargo hariç.",
		workshop.include.commission || workshop.include.tax ? "Fiyat, seçili komisyon ve KDV elinde kalsın diye şişirildi." : ""
	].filter(Boolean).join("\n");
}
function feePreview(workshop) {
	const price = 100;
	const commission = workshop.include.commission ? price * (Math.max(0, workshop.commissionRate) / 100) : 0;
	const taxPct = workshop.include.tax ? Math.max(0, workshop.taxRate) : 0;
	const tax = taxPct > 0 ? price * (taxPct / (100 + taxPct)) : 0;
	return {
		commission,
		tax,
		kept: price - commission - tax
	};
}
var TABS = [
	{
		id: "job",
		label: "İş"
	},
	{
		id: "shop",
		label: "Atölye"
	},
	{
		id: "sale",
		label: "Satış"
	}
];
var CHIPS = [
	{
		name: "Insert",
		amount: 4
	},
	{
		name: "Mıknatıs",
		amount: 6
	},
	{
		name: "Boya",
		amount: 8
	},
	{
		name: "Vida",
		amount: 3
	}
];
function CostForm({ job, workshop, profiles, onJob, onWorkshop, onInclude, onSaveProfile, onLoadProfile, onDeleteProfile, onExport, onImport, onAddExtra, onPatchExtra, onRemoveExtra }) {
	const [tab, setTab] = (0, import_react.useState)("job");
	const [profileName, setProfileName] = (0, import_react.useState)("");
	const fileRef = (0, import_react.useRef)(null);
	const preview = feePreview(workshop);
	const labor = laborAmount(job, workshop.laborRate);
	const qty = Math.max(1, Math.round(job.qty || 1));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-2xl border border-line bg-surface p-4 sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				role: "tablist",
				"aria-label": "Hesap bölümleri",
				className: "grid grid-cols-3 gap-1 rounded-xl bg-inset p-1",
				children: TABS.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					role: "tab",
					id: `tab-${item.id}`,
					"aria-selected": tab === item.id,
					"aria-controls": `panel-${item.id}`,
					className: `h-11 rounded-lg text-sm font-medium ${tab === item.id ? "bg-surface text-ink" : "text-muted"}`,
					onClick: () => setTab(item.id),
					children: item.label
				}, item.id))
			}),
			tab === "job" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "tabpanel",
				id: "panel-job",
				"aria-labelledby": "tab-job",
				className: "mt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Parça adı",
						hint: "Teklif metninde görünür. Boş bırakabilirsin.",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							className: "field",
							"aria-label": "Parça adı",
							maxLength: 80,
							value: job.name,
							placeholder: "Örn. kapak, aparat, yedek parça",
							onChange: (e) => onJob({ name: e.target.value })
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Block, {
						title: "Hammadde",
						detail: "Dilimleyicinin yazdığı gram. Destek aynı filamenttaysa o gramın içindedir.",
						included: workshop.include.material,
						onIncluded: (value) => onInclude("material", value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Filament",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
									label: "Filament tipi",
									value: job.filamentId,
									onChange: (id) => {
										const found = FILAMENTS.find((item) => item.id === id);
										onJob({
											filamentId: id,
											...found && found.price > 0 ? { filamentPrice: found.price } : {}
										});
									},
									options: FILAMENTS.map((item) => ({
										value: item.id,
										label: item.label
									}))
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Kg fiyatı",
								hint: "Senin son bobin fiyatın. Katalog değil.",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
									label: "Filament kilogram fiyatı",
									value: job.filamentPrice,
									onChange: (filamentPrice) => onJob({ filamentPrice })
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Harcanan filament, adet başı gram",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
									emptyZero: true,
									label: "Gram",
									value: job.grams,
									maxDecimals: 2,
									onChange: (grams) => onJob({ grams })
								})
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-line py-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-semibold",
								children: "Baskı süresi, adet başı"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: "Dilimleyicinin verdiği süre. Isınmayı ayrıca ekleme; gücü ortalamadan yaz."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid grid-cols-2 gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Saat",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
										integer: true,
										label: "Saat",
										value: job.hours,
										onChange: (hours) => onJob({ hours })
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Dakika",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
										integer: true,
										label: "Dakika",
										value: job.minutes,
										onChange: (minutes) => {
											if (minutes >= 60) onJob({
												hours: job.hours + Math.floor(minutes / 60),
												minutes: minutes % 60
											});
											else onJob({ minutes });
										}
									})
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-line py-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-semibold",
								children: "Adet ve tabla"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: "Plaka yıpranması parça başına değil, tabla döngüsü başına yazılır."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid gap-3 sm:grid-cols-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Adet",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
										label: "Adet",
										value: job.qty,
										min: 1,
										max: 999,
										onChange: (qty) => onJob({ qty })
									})
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
									label: "Bir tablaya sığan",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stepper, {
										label: "Tabla kapasitesi",
										value: job.perPlate,
										min: 1,
										max: 99,
										onChange: (perPlate) => onJob({ perPlate })
									})
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: "İkinci filament",
						detail: "Yalnızca farklı malzeme: PVA, arayüz, çok renk. Aynı filamentin desteğini buraya yazma.",
						included: workshop.include.support,
						onIncluded: (value) => onInclude("support", value),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Destek gramı, adet başı",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
									label: "Destek gramı",
									value: job.supportGrams,
									onChange: (supportGrams) => onJob({ supportGrams })
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Destek kg fiyatı",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
									label: "Destek kilogram fiyatı",
									value: job.supportPrice,
									onChange: (supportPrice) => onJob({ supportPrice })
								})
							})]
						})
					})
				]
			}) : null,
			tab === "shop" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "tabpanel",
				id: "panel-shop",
				"aria-labelledby": "tab-shop",
				className: "mt-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "border-b border-line py-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Yazıcı profili",
							hint: "Profil fiyat, ömür ve ortalama gücü doldurur. Piyasa rakamı değil, başlangıç. Nozzle ve plaka ayrı.",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectField, {
								label: "Yazıcı profili",
								value: workshop.printerId,
								onChange: (id) => {
									const found = PRINTERS.find((item) => item.id === id);
									if (!found) return;
									onWorkshop({
										printerId: id,
										...id === "ozel" ? {} : {
											watt: found.watt,
											printerCost: found.cost,
											printerLife: found.life
										}
									});
								},
								options: PRINTERS.map((item) => ({
									value: item.id,
									label: item.label
								}))
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: "Elektrik",
						detail: "Güç, baskı sırasındaki ortalama çekiştir. Güç kaynağının üzerindeki watt değil.",
						included: workshop.include.electricity,
						onIncluded: (value) => onInclude("electricity", value),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "kWh fiyatı",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
									label: "Elektrik birim fiyatı",
									value: workshop.elecRate,
									onChange: (elecRate) => onWorkshop({ elecRate })
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Ortalama güç, watt",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
									integer: true,
									label: "Ortalama güç",
									value: workshop.watt,
									onChange: (watt) => onWorkshop({
										watt,
										printerId: "ozel"
									})
								})
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: "Makine",
						detail: "Alış fiyatı bölü tahmin ettiğin ömür saati, baskı saatiyle çarpılır.",
						included: workshop.include.printer,
						onIncluded: (value) => onInclude("printer", value),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Yazıcı fiyatı",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
									label: "Yazıcı fiyatı",
									value: workshop.printerCost,
									onChange: (printerCost) => onWorkshop({
										printerCost,
										printerId: "ozel"
									})
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Ömür, saat",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
									integer: true,
									label: "Yazıcı ömrü",
									value: workshop.printerLife,
									onChange: (printerLife) => onWorkshop({
										printerLife,
										printerId: "ozel"
									})
								})
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: "Nozzle",
						detail: "Pirinç, düz PLA'da uzun gider. Karbon dolgulu filament ömrü ciddi kısar.",
						included: workshop.include.nozzle,
						onIncluded: (value) => onInclude("nozzle", value),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Nozzle fiyatı",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
									label: "Nozzle fiyatı",
									value: workshop.nozzleCost,
									onChange: (nozzleCost) => onWorkshop({ nozzleCost })
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Ömür, saat",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
									integer: true,
									label: "Nozzle ömrü",
									value: workshop.nozzleLife,
									onChange: (nozzleLife) => onWorkshop({ nozzleLife })
								})
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: "PEI plaka",
						detail: "Her tabla döngüsü bir baskı sayılır. Süre uzadıkça artmaz; dolu tabla birim fiyatı düşürür.",
						included: workshop.include.pei,
						onIncluded: (value) => onInclude("pei", value),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid gap-3 sm:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Plaka fiyatı",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
									label: "PEI plaka fiyatı",
									value: workshop.peiCost,
									onChange: (peiCost) => onWorkshop({ peiCost })
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Ömür, baskı sayısı",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
									integer: true,
									label: "PEI ömrü",
									value: workshop.peiLife,
									onChange: (peiLife) => onWorkshop({ peiLife })
								})
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: "Fire payı",
						detail: "Etek, kule, temizleme. Dilimleyici bunları grama kattıysa oranı düşür, yoksa iki kez yazılır.",
						included: workshop.include.waste,
						onIncluded: (value) => onInclude("waste", value),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Fire oranı, yüzde",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
								label: "Fire oranı",
								value: workshop.wasteRate,
								onChange: (wasteRate) => onWorkshop({ wasteRate })
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: "Başarısız baskı",
						detail: "Düz yüzde eklenmez. %10, iyi tabla çıkana kadar ortalama 1,11 deneme demektir.",
						included: workshop.include.fail,
						onIncluded: (value) => onInclude("fail", value),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Başarısızlık oranı, yüzde",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
								label: "Başarısızlık oranı",
								value: workshop.failRate,
								onChange: (failRate) => onWorkshop({ failRate: Math.min(100, failRate) })
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-line py-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-semibold",
								children: "Kayıtlı profiller"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: "Atölye ayarı bu tarayıcıda durur. Dosyaya da indirebilirsin."
							}),
							profiles.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 flex flex-col gap-2",
								children: profiles.map((profile) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "h-11 min-w-0 flex-1 truncate rounded-xl border border-line px-3 text-left text-sm",
										onClick: () => onLoadProfile(profile.id),
										children: profile.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										"aria-label": `${profile.name} profilini sil`,
										className: "grid size-11 place-items-center rounded-xl border border-line",
										onClick: () => onDeleteProfile(profile.id),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
											className: "size-4",
											"aria-hidden": true
										})
									})]
								}, profile.id))
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-col gap-2 sm:flex-row",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									className: "field",
									"aria-label": "Profil adı",
									placeholder: "Profil adı",
									maxLength: 40,
									value: profileName,
									onChange: (e) => setProfileName(e.target.value)
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									tone: "quiet",
									disabled: !profileName.trim(),
									onClick: () => {
										onSaveProfile(profileName.trim());
										setProfileName("");
									},
									children: "Profil kaydet"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: onExport,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {
											className: "size-4",
											"aria-hidden": true
										}), "Ayarları indir"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										onClick: () => fileRef.current?.click(),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {
											className: "size-4",
											"aria-hidden": true
										}), "Ayar yükle"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										ref: fileRef,
										type: "file",
										accept: "application/json",
										className: "sr-only",
										"aria-label": "Ayar dosyası yükle",
										onChange: (e) => {
											const file = e.target.files?.[0];
											if (file) onImport(file);
											e.target.value = "";
										}
									})
								]
							})
						]
					})
				]
			}) : null,
			tab === "sale" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				role: "tabpanel",
				id: "panel-sale",
				"aria-labelledby": "tab-sale",
				className: "mt-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Block, {
						title: "İşçilik",
						detail: `Hazırlık ${job.prepMin} dk siparişte bir kez, son işlem ${job.postMin} dk × ${qty} adet. Bu iş: ${formatTL(labor)}.`,
						included: workshop.include.labor,
						onIncluded: (value) => onInclude("labor", value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Saatlik ücret",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
								label: "Saatlik işçilik",
								value: workshop.laborRate,
								onChange: (laborRate) => onWorkshop({ laborRate })
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid grid-cols-2 gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Hazırlık, dakika",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
									integer: true,
									label: "Hazırlık dakikası",
									value: job.prepMin,
									onChange: (prepMin) => onJob({ prepMin })
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Son işlem, dakika",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
									integer: true,
									label: "Son işlem dakikası",
									value: job.postMin,
									onChange: (postMin) => onJob({ postMin })
								})
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: "Tasarım",
						detail: "Modele bir kez yazılır. Adet arttıkça birime bölünür.",
						included: workshop.include.design,
						onIncluded: (value) => onInclude("design", value),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Tasarım bedeli",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
								label: "Tasarım bedeli",
								value: job.design,
								onChange: (design) => onJob({ design })
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Block, {
						title: "Paketleme",
						detail: job.packagingPer === "piece" ? "Her parçaya ayrı paket." : "Siparişe bir kutu.",
						included: workshop.include.packaging,
						onIncluded: (value) => onInclude("packaging", value),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Paket tutarı",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
								label: "Paketleme tutarı",
								value: job.packaging,
								onChange: (packaging) => onJob({ packaging })
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								on: job.packagingPer === "order",
								onClick: () => onJob({ packagingPer: "order" }),
								children: "Sipariş başı"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
								on: job.packagingPer === "piece",
								onClick: () => onJob({ packagingPer: "piece" }),
								children: "Adet başı"
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: "Kargo",
						detail: "Siparişe bir kez. Teklif metninde dahil değilse ayrıca yazar.",
						included: workshop.include.shipping,
						onIncluded: (value) => onInclude("shipping", value),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Kargo tutarı",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
								label: "Kargo tutarı",
								value: job.shipping,
								onChange: (shipping) => onJob({ shipping })
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-line py-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-semibold",
								children: "Ek kalemler"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: "Insert, boya, vida. Adet başı olanlar başarısız denemeye de girer."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex flex-wrap gap-2",
								children: [CHIPS.map((chip) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "h-11 rounded-full border border-line px-3 text-sm",
									onClick: () => onAddExtra(chip.name, chip.amount),
									children: chip.name
								}, chip.name)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "h-11 rounded-full border border-line px-3 text-sm",
									onClick: () => onAddExtra("Ek", 0),
									children: "Boş satır"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 flex flex-col gap-3",
								children: job.extras.map((extra) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-xl border border-line p-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "grid gap-2 sm:grid-cols-[1fr_8rem_auto]",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
												className: "field",
												"aria-label": "Ek kalem adı",
												value: extra.name,
												maxLength: 40,
												onChange: (e) => onPatchExtra(extra.id, { name: e.target.value })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
												label: `${extra.name} tutarı`,
												value: extra.amount,
												onChange: (amount) => onPatchExtra(extra.id, { amount })
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												"aria-label": "Ek kalemi sil",
												className: "grid size-11 place-items-center rounded-xl border border-line",
												onClick: () => onRemoveExtra(extra.id),
												children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
													className: "size-4",
													"aria-hidden": true
												})
											})
										]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-2 grid grid-cols-2 gap-2",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
											on: extra.per === "piece",
											onClick: () => onPatchExtra(extra.id, { per: "piece" }),
											children: "Adet başı"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Choice, {
											on: extra.per === "order",
											onClick: () => onPatchExtra(extra.id, { per: "order" }),
											children: "Sipariş başı"
										})]
									})]
								}, extra.id))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: "Platform komisyonu",
						detail: "Müşterinin ödediği tutarın yüzdesi. Maliyetin üstüne eklenip tekrar çarpılmaz.",
						included: workshop.include.commission,
						onIncluded: (value) => onInclude("commission", value),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Komisyon, yüzde",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
								label: "Platform komisyonu",
								value: workshop.commissionRate,
								onChange: (commissionRate) => onWorkshop({ commissionRate: Math.min(80, commissionRate) })
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: "Vergi",
						detail: "KDV fiyata dahil sayılır. 20 yazınca fiyatın %20'si değil, %16,7'si vergidir.",
						included: workshop.include.tax,
						onIncluded: (value) => onInclude("tax", value),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "KDV, yüzde",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
								label: "Vergi oranı",
								value: workshop.taxRate,
								onChange: (taxRate) => onWorkshop({ taxRate: Math.min(80, taxRate) })
							})
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"100 TL tahsilatta komisyon ",
							formatTL(preview.commission),
							", vergi ",
							formatTL(preview.tax),
							", sana kalan ",
							formatTL(preview.kept),
							". Önerilen fiyat, çarpanı bu kalandan tutturacak kadar yükselir."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 border-t border-line pt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "text-sm font-semibold",
								children: "Satış çarpanları"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: "Çarpan, kesintiden sonra eline geçen bölü doğrudan maliyettir. Kesinti yoksa eski dosyandaki gibi fiyat = maliyet × çarpan."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 grid grid-cols-3 gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Minimum",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
											label: "Minimum çarpan",
											value: workshop.multiMin,
											onChange: (multiMin) => onWorkshop({ multiMin })
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Önerilen",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
											label: "Önerilen çarpan",
											value: workshop.multiRec,
											onChange: (multiRec) => onWorkshop({ multiRec })
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
										label: "Premium",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
											label: "Premium çarpan",
											value: workshop.multiMax,
											onChange: (multiMax) => onWorkshop({ multiMax })
										})
									})
								]
							})
						]
					})
				]
			}) : null
		]
	});
}
function Block({ title, detail, included, onIncluded, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "border-t border-line py-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-3 flex items-start justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-sm font-semibold",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs leading-relaxed text-muted",
					children: detail
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IncludeButton, {
				on: included,
				onChange: onIncluded,
				label: title
			})]
		}), children]
	});
}
function Choice({ on, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		"aria-pressed": on,
		onClick,
		className: `h-11 rounded-xl text-sm font-medium ${on ? "bg-ink text-surface" : "bg-inset text-muted"}`,
		children
	});
}
function QuotePanel({ job, workshop, analysis, quoteText, notes, onCustom, onQty, onNote, onRestore, onDeleteNote, onCopy }) {
	const prices = analysis.prices;
	const prod = analysis.lines.filter((line) => line.group === "prod");
	const work = analysis.lines.filter((line) => line.group === "work");
	const segments = analysis.lines.filter((line) => line.included && line.amount > 0 && analysis.direct > 0);
	const judged = prices ? judgePrice(job.customPrice, analysis) : null;
	const showLegacy = prices && analysis.linearPriceRec !== null && Math.abs(analysis.linearDirect - analysis.direct) >= .05;
	const ladderFlat = analysis.ladder.length > 1 && Math.max(...analysis.ladder.map((row) => row.unit)) - Math.min(...analysis.ladder.map((row) => row.unit)) < .5;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl bg-plate p-5 text-copper-ink sm:p-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-3 text-xs tracking-widest text-plate-muted uppercase",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Önerilen satış" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Hedef ", formatMult(workshop.multiRec)] })]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-display text-5xl leading-none tabular-nums sm:text-6xl",
						"aria-live": "polite",
						children: prices ? formatTLInt(prices.rec) : "—"
					}),
					prices ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-sm text-plate-muted",
							children: [
								Math.round(job.qty) > 1 ? `Adet başı ${formatTL(analysis.unitRec)} · ` : "",
								"Eline geçen ",
								formatTL(analysis.receivedOnRec),
								" · marj %",
								formatNum(analysis.marginOnRec, 1),
								" · ",
								formatMult(analysis.netMultiplier)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 grid grid-cols-2 gap-3 border-t border-plate-line pt-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-plate-muted",
									children: "Minimum"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-display text-2xl tabular-nums",
									children: formatTLInt(prices.min)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-plate-muted",
									children: formatMult(workshop.multiMin)
								})
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-plate-muted",
									children: "Premium"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-display text-2xl tabular-nums",
									children: formatTLInt(prices.max)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "text-xs text-plate-muted",
									children: formatMult(workshop.multiMax)
								})
							] })]
						}),
						analysis.excludedLabels.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-4 text-xs leading-relaxed text-plate-muted",
							children: ["Hariç: ", analysis.excludedLabels.join(", ")]
						}) : null
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 max-w-sm text-sm leading-relaxed text-plate-muted",
						children: analysis.problem ?? analysis.missing ?? "Gram ve süre yazılınca fiyat burada kurulur."
					})
				]
			}),
			analysis.problem && analysis.ready ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl bg-bad-bg px-4 py-3 text-sm text-bad",
				children: analysis.problem
			}) : null,
			prices ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Maliyet dökümü"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							"Cebinden çıkan ",
							formatTL(analysis.direct),
							Math.round(job.qty) > 1 ? ` · adet başı ${formatTL(analysis.unitDirect)}` : "",
							". Vergi ve komisyon bu toplama eklenmez, satışın içinden düşülür."
						]
					}),
					segments.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						"aria-hidden": true,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex h-3 overflow-hidden rounded-full bg-inset",
							children: segments.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: `h-full ${line.key === analysis.dominantKey ? "bg-copper" : "bg-ink"}`,
								style: { width: `${line.amount / analysis.direct * 100}%` }
							}, line.key))
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-xs text-muted",
							children: "Bakır dilim en büyük kalem."
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LineList, { lines: prod }),
					prod.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between border-t border-dashed border-line py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium",
							children: "Üretim"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums font-medium",
							children: formatTL(analysis.production)
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LineList, { lines: work }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-1 flex items-center justify-between border-t border-ink pt-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold",
							children: "Doğrudan maliyet"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-lg font-semibold",
							children: formatTL(analysis.direct)
						})]
					}),
					workshop.include.commission && workshop.commissionRate > 0 || workshop.include.tax && workshop.taxRate > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 rounded-xl bg-inset p-3 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: "Önerilen fiyattan düşen"
							}),
							workshop.include.commission && workshop.commissionRate > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Komisyon",
								value: formatTL(analysis.commissionOnRec)
							}) : null,
							workshop.include.tax && workshop.taxRate > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Vergi",
								value: formatTL(analysis.taxOnRec)
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Eline geçen",
								value: formatTL(analysis.receivedOnRec)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Kâr",
								value: formatTL(analysis.profitOnRec)
							})
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-2 flex items-center justify-between text-xs text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Kâr marjı, satış fiyatı üzerinden" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums",
									children: ["%", formatNum(analysis.marginOnRec, 1)]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-2 overflow-hidden rounded-full bg-inset",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: `h-full ${analysis.profitOnRec < 0 ? "bg-bad" : analysis.marginOnRec < 45 ? "bg-warn" : "bg-good"}`,
									style: { width: `${analysis.profitOnRec < 0 ? 100 : Math.max(0, Math.min(100, analysis.marginOnRec))}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 flex justify-between text-xs text-muted",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Maliyet ", formatTL(analysis.direct)] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Kâr ", formatTL(analysis.profitOnRec)] })]
							})
						]
					}),
					showLegacy ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 text-xs leading-relaxed text-muted",
						children: [
							"Eski dosyandaki düz yüzde ile başarısızlık ",
							formatTL(analysis.failLinear),
							", maliyet ",
							formatTL(analysis.linearDirect),
							", fiyat",
							" ",
							formatTLInt(analysis.linearPriceRec ?? 0),
							". Beklenen deneme sayısı bunu ",
							formatTL(analysis.failExpected),
							" yapıyor."
						]
					}) : null
				]
			}) : null,
			analysis.insights.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "flex flex-col gap-3",
				"aria-label": "Okuma",
				children: analysis.insights.map((insight) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: `border-l-2 pl-3 text-sm leading-relaxed text-ink ${insight.tone === "warn" ? "border-warn" : insight.tone === "good" ? "border-good" : "border-copper"}`,
					children: insight.text
				}, insight.id))
			}) : null,
			analysis.ladder.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Adet cetveli"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: ladderFlat ? "Bu ayarlarda adet arttıkça birim fiyat düşmüyor. Tabla kapasitesi, işçilik, tasarım, paket veya kargo paylaşılırsa düşer." : "Birim fiyat düşüyor: tabla, hazırlık veya sipariş kalemleri paylaşılıyor. Filament ve elektrik adetle doğru orantılı gider."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-[4.5rem_4.5rem_1fr] gap-2 text-xs text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Adet" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Tabla" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-right",
								children: "Önerilen"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-1",
						children: analysis.ladder.map((row) => {
							const current = Math.max(1, Math.round(job.qty || 1)) === row.qty;
							return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => onQty(row.qty),
								className: `grid h-11 w-full grid-cols-[4.5rem_4.5rem_1fr] items-center gap-2 rounded-lg px-1 text-left text-sm tabular-nums ${current ? "bg-inset font-semibold" : ""}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.qty }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.cycles }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-right",
										children: [formatTLInt(row.total), row.qty > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
											className: "ml-2 font-normal text-muted",
											children: [formatTL(row.unit), "/ad"]
										}) : null]
									})
								]
							}) }, row.qty);
						})
					})
				]
			}) : null,
			prices ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Kendi fiyatın"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NumField, {
							emptyZero: true,
							label: "Kendi satış fiyatın",
							placeholder: "Fiyat yaz",
							value: job.customPrice,
							onChange: onCustom
						})
					}),
					judged ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Eline geçen",
									value: formatTL(judged.received)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Kâr",
									value: formatTL(judged.profit),
									tone: judged.profit >= 0 ? "good" : "bad"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Marj",
									value: `%${formatNum(judged.margin, 1)}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Çarpan",
									value: formatMult(judged.multiplier)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
									label: "Gram başı kâr",
									value: `${formatNum(judged.perGram, 2)} TL/g`
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: `mt-3 rounded-xl px-3 py-3 text-sm ${judged.tone === "bad" ? "bg-bad-bg text-bad" : judged.tone === "warn" ? "bg-warn-bg text-warn" : "bg-good-bg text-good"}`,
							children: judged.text
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm text-muted",
						children: "Yazdığın fiyat, kesintilerden sonra eline geçene göre okunur."
					})
				]
			}) : null,
			quoteText ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-2xl border border-line bg-surface p-4 sm:p-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Müşteri metni"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: onNote,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NotebookPen, {
								className: "size-4",
								"aria-hidden": true
							}), "Not et"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							tone: "solid",
							onClick: onCopy,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {
								className: "size-4",
								"aria-hidden": true
							}), "Kopyala"]
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
					className: "mt-3 whitespace-pre-wrap font-sans text-sm leading-relaxed text-ink",
					children: quoteText
				})]
			}) : null,
			notes.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl",
				children: "Not edilen işler"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 flex flex-col gap-2",
				children: notes.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center gap-2 rounded-xl border border-line bg-surface px-3 py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						className: "min-w-0 flex-1 py-1 text-left",
						onClick: () => onRestore(note.id),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-sm font-medium",
							children: note.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-xs text-muted",
							children: [
								note.at,
								" · ",
								note.price
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						"aria-label": "Notu sil",
						className: "grid size-11 place-items-center rounded-xl",
						onClick: () => onDeleteNote(note.id),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
							className: "size-4",
							"aria-hidden": true
						})
					})]
				}, note.id))
			})] }) : null
		]
	});
}
function LineList({ lines }) {
	if (lines.length === 0) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: lines.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex items-start justify-between gap-3 border-b border-line py-2.5 last:border-b-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `text-sm font-medium ${line.included ? "text-ink" : "text-muted line-through"}`,
				children: line.label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs leading-relaxed text-muted",
				children: line.detail
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "shrink-0 text-right",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: `text-sm font-medium tabular-nums ${line.included ? "text-ink" : "text-muted"}`,
				children: formatTL(line.amount)
			}), line.included ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs text-muted",
				children: "hariç"
			})]
		})]
	}, line.key)) });
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-1 flex items-center justify-between gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "tabular-nums font-medium",
			children: value
		})]
	});
}
function Stat({ label, value, tone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-inset px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: `text-sm font-semibold tabular-nums ${tone === "bad" ? "text-bad" : tone === "good" ? "text-good" : "text-ink"}`,
			children: value
		})]
	});
}
function MethodNote() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
		className: "mt-4 rounded-2xl border border-line bg-surface p-4 sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
			className: "text-sm font-semibold",
			children: "Hesap nasıl kuruluyor"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
			className: "mt-3 flex list-disc flex-col gap-2 pl-4 text-sm leading-relaxed text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Hammadde = gram × adet / 1000 × kilogram fiyatı." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Fire, hammadde ve destek tutarının yüzde kadarıdır. Dilimleyici bu gramı zaten verdiyse oranı düşür, yoksa iki kez yazılır." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Elektrik = baskı saati × (ortalama watt / 1000) × kWh fiyatı. Güç kaynağı etiketi değil, baskı ortalaması. Isınma o ortalamanın içinde varsayılır; çok kısa işlerde elektrik bir miktar eksik kalabilir." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Makine = yazıcı fiyatı / ömür saati × baskı saati. Nozzle aynı mantık." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "PEI = plaka fiyatı / ömür baskı sayısı × tabla döngüsü. Döngü, adet bölü tabla kapasitesinin yukarı yuvarlağıdır. Süreye bağlı değildir." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Başarısızlık, değişken üretimin düz yüzdesi değildir. Oran p ise ek maliyet = taban × p / (1 − p). %10, iyi tabla başına 1,11 deneme demektir. Eski dosya burada düz %10 ekliyordu ve yüksek oranda eksik yazıyordu. İşçilik, tasarım, paket ve kargo bu çarpana girmez." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Eski dosyada kapattığın bir kalem, başarısızlık tutarının içinde kalabiliyordu. Artık yalnız dahil edilen üretim kalemleri riske girer." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "İşçilik = hazırlık bir kez + son işlem × adet, saatliğe bölünür." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Satış fiyatı, doğrudan maliyet × çarpan / kalan orandır ve liraya yukarı yuvarlanır. Kalan oran = 1 − komisyon − KDV / (100 + KDV). Komisyon müşterinin ödediği tutardandır. KDV fiyata dahildir." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Kâr marjı = kâr / satış fiyatı. Çarpan = kesintiden sonra eline geçen / doğrudan maliyet." })
			]
		})]
	});
}
function Calculator() {
	const [data, setData] = (0, import_react.useState)(defaults);
	const [hydrated, setHydrated] = (0, import_react.useState)(false);
	const [notice, setNotice] = (0, import_react.useState)(null);
	const [confirmReset, setConfirmReset] = (0, import_react.useState)(false);
	const dataRef = (0, import_react.useRef)(data);
	dataRef.current = data;
	(0, import_react.useEffect)(() => {
		setData(loadPersisted());
		setHydrated(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!hydrated) return;
		savePersisted(data);
	}, [data, hydrated]);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "s") {
				event.preventDefault();
				savePersisted(dataRef.current);
				flash("Bu tarayıcıya kaydedildi.");
			}
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	function flash(message) {
		setNotice(message);
		window.setTimeout(() => setNotice(null), 2600);
	}
	function patchJob(patch) {
		setData((current) => ({
			...current,
			job: {
				...current.job,
				...patch
			}
		}));
	}
	function patchWorkshop(patch) {
		setData((current) => ({
			...current,
			workshop: {
				...current.workshop,
				...patch
			}
		}));
	}
	function patchInclude(key, value) {
		setData((current) => ({
			...current,
			workshop: {
				...current.workshop,
				include: {
					...current.workshop.include,
					[key]: value
				}
			}
		}));
	}
	const analysis = (0, import_react.useMemo)(() => quote(data.job, data.workshop), [data.job, data.workshop]);
	const quoteText = buildQuote(data.job, data.workshop, analysis);
	const burn = analysis.burn;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-bg text-ink",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-1.5 bg-copper" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "mx-auto flex max-w-6xl flex-col gap-4 px-4 pt-6 pb-2 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-2 flex flex-col gap-1",
						"aria-hidden": true,
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-1 w-8 rounded-full bg-copper" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-1 w-8 rounded-full bg-ink" }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "block h-1 w-5 rounded-full bg-copper" })
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium tracking-widest text-muted uppercase",
							children: "Atölye defteri"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-4xl leading-none sm:text-5xl",
							children: "3D baskı maliyeti"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xl text-sm text-muted",
							children: "Filament fiyatı işin küçük kısmı. Saatlik yanma, tabla, fire ve başarısız deneme de yazılır."
						})
					] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						onClick: () => patchJob(applyExample(data.job)),
						children: "Örnek iş"
					}), confirmReset ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						tone: "solid",
						onClick: () => {
							setData(defaults());
							setConfirmReset(false);
							flash("Dosyandaki başlangıca dönüldü.");
						},
						children: "Eminim, sıfırla"
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => setConfirmReset(true),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {
							className: "size-4",
							"aria-hidden": true
						}), "Sıfırla"]
					})]
				})]
			}),
			notice ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mx-auto mt-3 max-w-6xl px-4 text-sm text-copper-deep",
				role: "status",
				children: notice
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-6xl px-4 pt-4 pb-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid grid-cols-2 gap-px overflow-hidden rounded-2xl border border-line bg-line sm:grid-cols-4",
						"aria-label": "Tezgahın saatlik yanması",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BurnCell, {
								label: "Makine",
								value: formatTL(burn.printerPerHour),
								note: data.workshop.include.printer ? "Saatlik, fiyata dahil" : "Saatlik, şu an hariç"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BurnCell, {
								label: "Nozzle",
								value: formatTL(burn.nozzlePerHour),
								note: data.workshop.include.nozzle ? "Saatlik, fiyata dahil" : "Saatlik, şu an hariç"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BurnCell, {
								label: "Elektrik",
								value: formatTL(burn.elecPerHour),
								note: data.workshop.include.electricity ? "Saatlik, fiyata dahil" : "Saatlik, şu an hariç"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BurnCell, {
								label: "Tabla",
								value: formatTL(burn.peiPerPlate),
								note: data.workshop.include.pei ? "Her döngü, fiyata dahil" : "Her döngü, şu an hariç"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "sticky top-0 z-20 -mx-4 mt-4 border-b border-line bg-bg px-4 py-3 lg:hidden",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-baseline justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs tracking-widest text-muted uppercase",
								children: "Önerilen"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-display text-4xl leading-none tabular-nums",
								children: analysis.prices ? formatTL(analysis.prices.rec, 0) : "—"
							})]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid items-start gap-4 lg:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-w-0",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CostForm, {
								job: data.job,
								workshop: data.workshop,
								profiles: data.profiles,
								onJob: patchJob,
								onWorkshop: patchWorkshop,
								onInclude: patchInclude,
								onSaveProfile: (name) => {
									setData((current) => ({
										...current,
										profiles: [{
											id: uid(),
											name,
											workshop: current.workshop
										}, ...current.profiles].slice(0, 12)
									}));
									flash("Profil kaydedildi.");
								},
								onLoadProfile: (id) => {
									const profile = data.profiles.find((item) => item.id === id);
									if (!profile) return;
									setData((current) => ({
										...current,
										workshop: profile.workshop
									}));
									flash(`${profile.name} yüklendi.`);
								},
								onDeleteProfile: (id) => {
									setData((current) => ({
										...current,
										profiles: current.profiles.filter((item) => item.id !== id)
									}));
								},
								onExport: () => {
									const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
									const url = URL.createObjectURL(blob);
									const link = document.createElement("a");
									link.href = url;
									link.download = "baski-maliyet-ayarlari.json";
									link.click();
									URL.revokeObjectURL(url);
									flash("Ayar dosyası indirildi.");
								},
								onImport: (file) => {
									file.text().then((text) => {
										setData(normalizePersisted(JSON.parse(text)));
										flash("Ayar dosyası yüklendi.");
									}).catch(() => flash("Dosya okunamadı."));
								},
								onAddExtra: (name, amount) => {
									const extra = {
										id: uid(),
										name,
										amount,
										per: "piece"
									};
									setData((current) => ({
										...current,
										job: {
											...current.job,
											extras: [...current.job.extras, extra].slice(0, 12)
										}
									}));
								},
								onPatchExtra: (id, patch) => {
									setData((current) => ({
										...current,
										job: {
											...current.job,
											extras: current.job.extras.map((extra) => extra.id === id ? {
												...extra,
												...patch
											} : extra)
										}
									}));
								},
								onRemoveExtra: (id) => {
									setData((current) => ({
										...current,
										job: {
											...current.job,
											extras: current.job.extras.filter((extra) => extra.id !== id)
										}
									}));
								}
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "min-w-0 lg:sticky lg:top-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QuotePanel, {
								job: data.job,
								workshop: data.workshop,
								analysis,
								quoteText,
								notes: data.notes,
								onCustom: (customPrice) => patchJob({ customPrice }),
								onQty: (qty) => patchJob({ qty }),
								onNote: () => {
									if (!analysis.prices) return;
									const note = {
										id: uid(),
										at: (/* @__PURE__ */ new Date()).toLocaleString("tr-TR"),
										name: data.job.name.trim() || "Adsız iş",
										price: formatTL(analysis.prices.rec, 0),
										job: data.job
									};
									setData((current) => ({
										...current,
										notes: [note, ...current.notes].slice(0, 8)
									}));
									flash("İş not edildi.");
								},
								onRestore: (id) => {
									const note = data.notes.find((item) => item.id === id);
									if (!note) return;
									setData((current) => ({
										...current,
										job: note.job
									}));
									flash("Not edilen iş geri geldi.");
								},
								onDeleteNote: (id) => {
									setData((current) => ({
										...current,
										notes: current.notes.filter((item) => item.id !== id)
									}));
								},
								onCopy: () => {
									if (!quoteText) return;
									navigator.clipboard.writeText(quoteText).then(() => flash("Teklif panoya kopyalandı.")).catch(() => flash("Kopyalanamadı. Metni seçebilirsin."));
								}
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MethodNote, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-6 text-center text-xs leading-relaxed text-muted",
						children: "Tavsiye niteliğindedir. Elektrik, nozzle ve plaka rakamları senin girdiğin tezgah ayarıdır — eski dosyandaki 4,50 TL/kWh ve 120 W başlangıç olarak duruyor. Ayarlar bu tarayıcıda saklanır. Ctrl+S de aynı yere yazar."
					})
				]
			})
		]
	});
}
function BurnCell({ label, value, note }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-surface px-4 py-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "text-xs text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 font-display text-xl leading-none tabular-nums sm:text-2xl",
				children: value
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-1 text-xs text-muted",
				children: note
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Calculator, {});
}
//#endregion
export { Home as component };
